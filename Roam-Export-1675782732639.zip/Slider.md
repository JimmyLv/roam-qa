Sliders are good for representing data on a scale, and are especially useful for polls on [[Multiplayer]] graphs!

Type `{{[[slider]]}}` (or select `Slider` after [typing]([[/ Commands]]) `/`) to conjure one:

{{[[slider]]}}

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FqaRPRyZuKx.gif?alt=media&token=3a89f74b-4888-4b79-9efa-35d27e88fd23)

Other users can click on the slider to give their rating as well

