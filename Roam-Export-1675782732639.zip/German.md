### Roam Research - die BESTE Notizen App? by [[Johannes Weigl]]

{{[[video]]: https://www.youtube.com/watch?v=I3df_pSJLjo}}
#[[Graph Overview]] | #[[Search]] | #[[Daily Notes]]

