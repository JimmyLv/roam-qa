### How to add emojis and remove them

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FL5apSH6m5c.gif?alt=media&token=506b7589-f468-4feb-9601-358cb8d868c4)

[[.--]]

