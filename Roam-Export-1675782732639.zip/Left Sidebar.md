### Star/unstar pages

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FNRorx4Exjz.gif?alt=media&token=f944f398-c784-468f-8dd6-d29a5cc5e945)

### Drag and drop to reorder shortcuts

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FNNB1u-Q7BF.gif?alt=media&token=8b3ced99-39ae-4973-83f3-9930dda79b09)

### Dropdown menu to access graphs

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FeFf25Fq_-A.gif?alt=media&token=f8a7adc0-6992-4b9e-9b1b-75ef0f209220)

