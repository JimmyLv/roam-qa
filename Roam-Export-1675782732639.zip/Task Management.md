## Community Videos::

### Roam Research for Daily Task Management using Bullet Journaling Method by [[The Upgraded Brain]]

{{[[video]]: https://www.youtube.com/watch?v=ftv6ew7Tcbg&t}}
#[[Templates]] | #[[Slider]] | #[[TODO/DONE]] | #[[Sidebar]]

### Simple Task Management with Roam Research by [[Mickey Mellen]]

{{[[video]]: https://www.youtube.com/watch?v=Au4WnEqdJU0}}
#[[Current time]] | #[[Query]] | #[[Page References]] | #[[Attributes]] | #[[Tags]]

### Task Management, Roam Research: Inbox, Contexts, & Projects by [[R.J. Nestor]]

{{[[video]]: https://www.youtube.com/watch?v=5wI0il4YVDg}}
#[[Query]] | #[[Task Management]] | #[[TODO/DONE]] | #[[Tags]] 


### Roam Research: TODOs by [[Les Kristofs]]

{{[[video]]: https://www.youtube.com/watch?v=3taL1v-IKXg}}
#[[TODO/DONE]] | #[[Linked References]] | #[[/ Commands]]

### Roam: How to Make a Master Task List on Roam by [[Shu Omi]]

{{[[video]]: https://www.youtube.com/watch?v=mIEgS0JkJBo&t=5s&ab_channel=ShuOmi}}
#[[TODO/DONE]] | #[[Page References]] | #[[Filter]] | #[[Daily Notes]] 

### Plan Your Day With The Magic List (Roam Research Task Management) by [[Daniel Wirtz]]

{{[[video]]: https://www.youtube.com/watch?v=5U62cEE7QsM&t=6s&ab_channel=DanielWirtz}}
#[[TODO/DONE]] | #[[Query]] | #[[Page References]] | #[[Daily Notes]] | #[[Block References]] 

Roam Team Videos::

### Task Management by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=3aCl7dCYVqA&t=6s&ab_channel=ConorWhite-Sullivan}}
#[[TODO/DONE]] | #[[Daily Notes]] | #[[Filter]] | #[[Linked References]] | #[[Block Embed]] | #[[Current time]] | #[[Block References]]

### Tasks in Roam by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=asQ4RSjjCu4&ab_channel=ConorWhite-Sullivan}}
#[[TODO/DONE]] | #[[Linked References]] 

Articles::

### [Using Roam Research for GTD-Style Task Management – The Sweet Setup](https://thesweetsetup.com/using-roam-research-for-gtd-style-task-management/)

#[[Daily Notes]] | #[[TODO/DONE]] | #[[Page References]] | #[[Query]] | #[[Linked References]] 

### [Using TODO to Get Things Done with Roam Research (GTD) — Roam Tips & Hacks](https://www.roamtips.com/home/use-todo-get-things-done-roam-research-gtd)

#[[TODO/DONE]] | #[[Page References]] | #[[Date picker]] | #[[Filter]]

