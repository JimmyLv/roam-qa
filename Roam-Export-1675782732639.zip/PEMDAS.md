The order of operations for evaluating math equations

Parenthesis

Exponents

Multiplication

Division

Addition

Subtraction

