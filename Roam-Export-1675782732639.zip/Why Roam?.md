This thread of threads on Twitter answers the question of "Why Roam?" pretty well, if not succinctly 😉

https://twitter.com/Conaw/status/1198399750032232449?s=20a

*Conor mentions the old help graph in this thread. If you are searching for the white paper, he mentioned, find it in this graph [here]([[White Paper]]).



Community Videos::

### Exploring Networked Thought: The Story of Roam Research by [[Futurism]]

{{[[video]]: https://www.youtube.com/watch?v=EqyJweIHaeg}}
#[[Bidirectional linking]]

