# [Journaling]([[Journaling]])

# [Longform writing]([[Longform writing]])

# [Meeting notes]([[Meeting notes]])

# [Zettelkasten]([[Zettelkasten]])

# [Research]([[Research]])

# [Studying]([[Studying]])

# [Task Management]([[Task Management]])

# [Project Management]([[Project Management]])

# [Personal CRM]([[Personal CRM]])

# [Miscellaneous]([[Miscellaneous]]) 





