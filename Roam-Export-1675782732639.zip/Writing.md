# [[Journaling]]

# [[Longform writing]]

# [[Meeting notes]]

# [[Zettelkasten]]

