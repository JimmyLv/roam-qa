Date picker helps you pick a date's page by showing you a calendar

{{date}}

Roam Team Videos::

Scheduling with Roam by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=ByiFhtlI66A}}
#[[Linked References]] | #[[TODO/DONE]] | #[[Date picker]]

Community Videos::

How to Build a Weekly Schedule in Roam by [[Dalton Mabery]]

{{[[video]]: https://www.youtube.com/watch?v=E8GW5QhY9VY}}
#[[Date picker]] | #[[TODO/DONE]] | #[[Tags]] | #[[Filter]] | #[[Linked References]] | #[[Query]]

Key Commands::

`/date`

