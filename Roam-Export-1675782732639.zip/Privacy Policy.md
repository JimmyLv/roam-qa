### **TLDR: **Roam does not own your data, nor do we sell it to others or use it for advertising. We will never read or access your private notes without written or verbal consent - unless compelled by law enforcement.

As a quick reminder, here is our policy on User Content as per the [[Terms and Conditions]]:

**I. Content.**

Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material ("Content") on the Service. You are responsible for the Content that you post on or through the Service, including its legality, reliability, and appropriateness.

By posting Content on or through the Service, you represent and warrant that: (a) the Content is yours and/or you have the right to use it and the right to grant us the rights and license as provided in these Terms, and (b) that the posting of your Content on or through the Service does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person or entity. We reserve the right to terminate the account of anyone found to be infringing on a copyright. 

You retain any and all of your rights to any Content you submit, post or display on or through the Service and you are responsible for protecting those rights. We take no responsibility and assume no liability for Content you or any third-party posts on or through the Service. When you post Content into certain Databases, you will be able to designate whether such Content is made publicly or privately available.

As a condition of your use of the Service, you grant Roam a nonexclusive, perpetual, irrevocable, royalty-free, worldwide, transferable, sub-licenseable license to access, use, host, cache, store, reproduce, transmit, display, publish, distribute, modify and adapt and create derivative works (either alone or as part of a collective work) from your public Content. This license does not apply to content in private databases. **Furthermore, while Roam has the technical ability to access private content, we agree to never access private content without written or verbal consent from you - excluding cases where we are compelled by legal authorities.** As part of the foregoing license grant you agree that (a) the other users of the Service shall have the right to comment on and/or tag your public Content that you make available to them and/or to use, publish, display, modify or include a copy of your public Content that you make available to them, and (b) we have the right to make any of your public Content available to third parties, so that those third parties can distribute, make derivative works of, comment on and/or analyze your Content on other media and services (either alone or as part of a collective work); except that the foregoing (a) and (b) shall not apply to any of your Content that you post privately for non-public display on the Service.

By posting Content that is set for public access to the Service, you grant us the right to display such public Content on and through the Service. Roam has the right but not the obligation to monitor all Content provided by users. In addition, any Content found on or through this Service that is not originally submitted, posted, or displayed by Users of the Service is the property of Roam or used with permission. You may not distribute, modify, transmit, reuse, download, repost, copy, or use said Content, whether in whole or in part, for commercial purposes or for personal gain, without express advance written permission from us.

You agree that Roam has the right, but not the obligation, to remove any Content from the Service if Roam determines in its sole discretion that such Content has violated these Terms, the Roam Privacy Policy, applicable law, or the privacy rights, publicity rights, intellectual property, contract rights or any other rights of any person or entity, or if Roam determines in its sole discretion that such Content poses a risk of harm to Roam, other users of the Service or third parties.

Any content stored on the Service will be stored indefinitely, unless it is explicitly deleted. This process is described in Article 2, Section XIV, Termination or Cancellation of Agreement.



### 1. Introduction

1.1. This Privacy Policy applies to both registered **“Members”** and unregistered **“Visitors”** for use of the Roam Research website, operated by Roam Research, Inc. ("Roam", "us", "we", or "our") and of the Roam Services. Both Members and Visitors are hereinafter referred to as **“User(s)”**. By clicking “Join Now,” “Join Roam,” “Sign Up” or similar, registering, accessing or using our Services, User is entering into a legally binding agreement (either individually or on behalf of a Company) that includes the Roam Terms and Conditions and this Privacy Policy.

1.2. This Privacy Policy applies to all Users of www.roamresearch.com and the Roam mobile site, and all other Roam websites, apps, developer platforms, management and transaction services, premium services, other products and services offered by Roam, or any content or information provided as part of these services, including our blog (collectively, the **“Services”**).

1.3. This Privacy Policy is effective upon use of any Roam Services by all Users.

1.4. This Privacy Policy describes how we handle Users’ personal information for our Services. By accepting this Privacy Policy, User expressly consents to Roam’s collection, storage, use and disclosure of User’s personal information as described in this Privacy Policy.

1.5. Roam may modify this Privacy Policy from time to time. If we make material changes to this Privacy Policy, we will provide notice by email, to the email address on file in User’s Roam account at the time of notice. Immediately after such notice has been provided to User, continued use of the Services constitutes User’s understanding, consent and acceptance of this Privacy Policy.

### 2. Collection

2.1. Data Controllers. Roam uses servers that may be located anywhere in the world, including but not limited to, the United States or other countries. If User has any concern about providing information to Roam as detailed in this Privacy Policy, User should not become a Member, visit our sites, applications, or otherwise use our Services.

2.2. Account Registration. When User creates an account on Roam, User may be required to provide some personal information, including, but not limited to, User’s name, email address, home, work, or mobile telephone number, facility address, mailing address, bank account information, credit card number, and a password. User will also be required to agree to the Roam Terms and Conditions, which includes our User Agreement, Terms of Service, and this Privacy Policy. Once User provides this information to Roam, User is no longer anonymous to us. When User provides us with its personal and financial information, User consents to the transfer and storage of that information on our servers, which may be located anywhere in the world, including but not limited to, the United States or other countries.

2.3. Client Services. When User contacts our Client Services support team, either by email or phone, Roam may access User’s account, settings, preferences, emails, and other contributions to our Services and collect the information needed to categorize User’s question, respond to it, and, if applicable, investigate any breach of our Terms and Conditions or this Privacy Policy. Roam will also use this information to track potential problems and trends and customize support responses to better serve our Users.

2.4. Using the Roam Sites, Services and Applications. By using our Services, User understands that Roam may collect the following information, in addition to the information specified in **Section 2.2** hereof:

2.4.1. Correspondence through our sites, or correspondence sent to any Roam employee or email address, or via telephone correspondence;

2.4.2. Any other information provided during User’s interaction with the site, Services, and content, including, but not limited to, computer and network information, statistics on page views, traffic to and from sites, IP addresses and standard web log information; and

2.4.3. Information from other companies, generation reporting companies, such as demographic and traffic data. 

2.5. Collection of New Data. Roam’s Services are constantly evolving, as we work to continue to provide the best suite of Services to our Users. The introduction of new Services may result in the collection of new information. Additionally, new partnerships or corporate mergers or acquisitions may result in new Services that require the collection of new information. If we start collecting substantially new types of personal or financial information in a way that materially impacts how we handle our Users’ data, we will modify this Privacy Policy in accordance with **Section 1.5** hereof.

2.6. Cookies, Pixel Tags/Web Beacons, and Analytics Information. We, as well as third parties that provide content, advertising, or other functionality on the Services, may use cookies, pixel tags, local storage, and other technologies (“Technologies”) to automatically collect information through the Services. Technologies are essentially small data files placed on your devices that allow us and our partners to record certain pieces of information whenever you visit or interact with our Services.

2.6.1. Cookies. Cookies are small text files placed in device browsers to store their preferences. Most browsers allow you to block and delete cookies. However, if you do that, the Services may not work properly.

2.6.2. Pixel Tags/Web Beacons: A pixel tag (also known as a web beacon) is a piece of code embedded in the Services that collects information about engagement on the Services. The use of a pixel tag allows us to record, for example, that a user has visited a particular web page or clicked on a particular advertisement. We may also include web beacons in e-mails to understand whether messages have been opened, acted on, or forwarded.

2.6.3. Analytics: We may also use third-party service providers to collect and process analytics and other information on our Services. These third-party service providers may use cookies, pixel tags, web beacons or other storage technology to collect and store analytics and other information. They have their own privacy policies addressing how they use the analytics and other information and we do not have access to, nor control over, third parties’ use of cookies or other tracking technologies.

2.7. Information Collected from Users’ Devices and Networks. When User visits or leaves our Services (whether as a Member of Visitor) by clicking a hyperlink, or when User views a third party website that includes our Cookies or similar technology, Roam automatically receives the URL of the site from which User comes or the one to which User is directed. Additionally, Roam receives the internet protocol (**“IP”**) address of User’s company or the proxy server that User uses to access the web, User’s computer operating system details, User’s type of web browser, User’s mobile device (including User’s mobile device identifier provided by User’s mobile device operating system), User’s mobile operating system (if User is accessing Roam via a mobile device), and the name of User’s ISP or mobile carrier. Roam may also receive location data passed to us from a third party service provider or GPS-enabled devices that User has set up, which Roam may use to show User’s local information and for fraud prevention and security purposes. User understands that most mobile devices have settings to disable the sharing of real-time location data, and that User should enable these settings if it does not wish to share this information with Roam.

2.8. Social Media Widgets. A **“Widget”** is a stand-alone application used on our sites to display information or to invite Users to interact with the sites and Services in a variety of ways. Such Widgets include the Facebook “Like” button and the Twitter “Tweet”, or any other “Share” button that allows User to share content on a number of social media websites. These Widgets may collect User’s IP address, which page User is visiting on our sites, and may set a Cookie to enable the feature to function properly. User understands that social media features and Widgets are hosted by a third party or directly on our sites. Irrespective of host, User understands that these features are governed by the third party privacy policies of the company providing the feature.

### 3. Use of User's Data

3.1. Roam collects personal and financial information in order to provide User with a safe, smooth, efficient and customized experience. User understands, accepts, and consents that Roam is authorized to use User’s personal and financial information in the following ways:

3.2. General. Roam is authorized to use User’s personal and financial information to:

3.2.1. Provide the Services and client services support requested by User;

3.2.2. Resolve disputes, collect Fees, and troubleshoot problems;

3.2.3. Enforce the Roam Terms and Conditions and this Privacy Policy;

3.2.4. Customize, measure and improve its Services and content;

3.2.5. Inform User about Service updates, changes, and promotions; and

3.2.6. Compare information for accuracy, and to verify it with third parties.

3.3. Communication. Roam may communicate with its Users via telephone, email, notices posted on the Roam sites or apps, direct messages, and other means available through the Services. Communications may include welcome and setup communications, Service communications, promotional communications, and other account support communications. These communications will be sent to User based on User’s account information and communication preferences. User understands and acknowledges, however, that User cannot opt out of receiving Service communications from Roam.

3.3.1. User consents to receive autodialed or prerecorded calls and text messages at the telephone number provided on the User’s account, or at any other telephone number provided by the User to Roam, regardless of whether the telephone number is a home, work, or mobile telephone number. Where applicable and permitted by law, User may decline to receive certain communications by opting out via express written notice to Roam.

3.4. Data Analysis. Roam may share certain User data with companies with whom Roam co-markets, partners, and collaborates for their analysis and internal use to provide Users with additional Services. Roam may use and disclose de-identified data shared with Roam either by the User or a third party providing data on behalf of the User, for any purpose. Any and all of this information may be aggregated with information from other Users or may be provided individually in a redacted format as an example of User experience and our Services. Roam is also expressly authorized by User to share with third parties, aggregate and/or de-identified data, including User’s use of the Services provided to User by Roam. 

However, Roam will collect and share additional, identified and/or personal location information about User as specified under Section II hereof and as detailed in the Roam [[Terms and Conditions]]. 

3.5. Data Sharing with Third Parties. In addition to the sharing specified in **Section 3.4** hereof, Roam may disclose User’s personal and financial information to third party services providers who assist Roam in providing our Services. User understands and accepts that Roam may contract with other companies and individuals to perform certain functions on our behalf, or to provide User with certain services. This includes, but is not limited to, processing credit card payments, issuing ACH deposits, sending postal mail and email, analyzing data, and providing marketing assistance. These third parties will only have access to personal information to the extent necessary to perform their intended function or service and are not authorized to use it for other purposes.

3.6. Marketing. Roam will not sell or rent User’s personal information to third parties for their marketing purposes without User’s explicit consent. However, Roam reserves the right to use User’s information to improve and personalize its Services and content. If User does not wish to receive marketing communications from us, User may indicate this preference at the bottom of Roam’s marketing emails.

3.7. Spam. Roam does not tolerate “Spam”. User is not licensed to add other Roam Users to User’s mailing list (email or postal mail) without that User’s express written consent. To report Roam-related Spam or Spoof emails to Roam, User should forward the suspected Spam or Spoof email to Roam with a notice that the email may be Spam or Spoof. User may not use Roam’s communication channels to send Spam or otherwise send content that would violate the Roam User Agreement. Roam automatically scans and may manually filter messages to check for Spam, viruses, phishing attacks and other malicious activity or illegal or prohibited content, and Roam does not permanently store messages sent through these filters.

### 4. Security

4.1. All information processed by us may be transferred, processed, and stored anywhere in the world, including but not limited to, the United States or other countries, which may have data protection laws that are different from the laws where you live. We treat data as an asset that must be protected and use encryption, passwords, physical security and other security protocols to protect Users’ personal and financial information against unauthorized access and disclosure. However, third parties may unlawfully intercept or access transmission or private communications made between User and Roam or between Users of Roam, and other Users may abuse or misuse Users’ personal information that they collect from the sites. Therefore, to the extent permitted by law, User agrees to hold harmless Roam in the event that a third party unlawfully intercepts or accesses any information provided by User to Roam.

4.2. Account Access. User’s password is the key to User’s account. User should use unique numbers, letters and special characters, and should not disclose its Roam account password to anyone. If User does share its password or its personal information with others, User acknowledges and understands that User is responsible for all action taken in the name of User’s account. If User loses control of its password, User may lose substantial control over its personal and financial information and may be subject to legally binding actions taken on User’s behalf. If User’s password has been compromised for any reason, User should immediately contact and notify Roam and User should change its password.

### 5. Data Modification and Retention

5.1. User can see, review and change most of its personal and financial information by signing into User’s Roam account. Generally, Roam will not manually modify User’s personal or financial information because it is difficult to verify your identity remotely. Accordingly, we strongly encourage, and sometimes require, Users to update their personal and financial information directly in their Roam account if it changes or is inaccurate.

5.2. Upon User’s written request, Roam will close User’s account and remove User’s personal and financial information from view as soon as reasonably practicable, based on User’s account activity and in accordance with applicable law. However, User acknowledges, understands and consents that Roam may retain User’s personal and financial information from closed accounts to comply with the law, prevent fraud, collect any fees owed, resolve disputes, troubleshoot problems, assist with any investigations, enforce the Roam Terms and Conditions, and take other actions otherwise permitted by law.

5.3. We store the personal information we receive as described in this Privacy Policy for as long as you use our Services or as necessary to fulfill the purpose(s) for which it was collected, provide our Services, resolve disputes, establish legal defenses, conduct audits, pursue legitimate business purposes, enforce our agreements, and comply with applicable laws.

### 6. Disclosure

6.1. Roam may disclose personal or financial information to respond to legal requirements, to enforce our policies, or to protect anyone’s rights or property. Accordingly, User’s information may be shared with:

6.1.1. Members of the Roam corporate family to help detect and prevent potentially illegal acts;

6.1.2. Service providers under contract who provide assistance for our business operations (such as fraud investigations and bill collection);

6.1.3. Law enforcement or other governmental officials, in response to a verified request relating to a criminal investigation or alleged illegal activity. In such events, Roam may disclose information relevant to the investigation, including name, city, state, zip code, telephone number, email address, user ID history, IP address, fraud complaints, and bid and offer (order) history;

6.1.4. Other business entities, should Roam plan to merge with or be acquired by that business entity. Should a merger or acquisition occur, Roam will require that the new entity follow this Privacy Policy with respect to User’s personal and financial information. If User’s personal or financial information will be used in a manner contrary to this Privacy Policy, User will receive notice.

6.2 We may also share your personal information with other third parties, including other users, in the following circumstances:

6.2.1. Databases Accessible by Other Users: When you submit personal information in a database that can be accessed by others, such personal information may be displayed to other users in the same or connected databases. For example, your personal information may be included in your notes or reminders in a database which can be viewed by other users collaborating with you in that database. Further, your email address or photo may be displayed with your database profile to other users collaborating with you in that database. This may apply to both Public Databases and Private Databases from within which you have shared a specific page.

6.2.2. Share Content with Friends or Colleagues: Our Services may allow you to provide information about your friends, and may allow you to forward or share certain content with a friend or colleague, such as an invitation email.

6.3.Without limiting the authorizations under **Section 4.1** hereof, and in an effort to respect User’s privacy and our ability to keep the community free from bad actors, Roam will not otherwise disclose User’s personal or financial information to law enforcement, other government officials, or other third parties without a subpoena, court order, or substantially similar legal procedure, except when we believe in good faith that the disclosure of information is necessary to prevent imminent physical harm or financial loss or to report suspected illegal activity.

### 7. Children’s Information

The Services are not directed to children under 13 (or other age as required by local law), and we do not knowingly collect personal information from children. If you learn that your child has provided us with personal information without your consent, you may contact us as set forth below. If we learn that we have collected a child’s personal information without parental consent in violation of applicable law, we will promptly take steps to delete such information and terminate the child’s account.

### 8. Copyright

8.1.Some data available on Roam is protected by copyright laws and may contain material proprietary to Roam Research, Inc. This data or any of its components may not be reproduced, republished, distributed, transmitted, displayed, broadcasted, or otherwise disseminated or exploited in any manner without the express prior written permission of Roam Research, Inc. The receipt or possession of this data or any of its components does not convey any rights to reproduce, disclose, or distribute its contents, or to manufacture, use, or sell anything that it may describe, in whole or in part. If consent to use specific data is granted, a link to the current version of that data on the Roam website must be included for reference and sourcing. If you have questions about the use or reproduction of data available on Roam’s sites, please contact us.

