Good morning! Today's a great day to test out the mobile interface! :)

Indenting is cool. But I don't foresee anyone 

Ever moving their stuff using these icons. But I might.  Be wrong. The thing is that the menu bar thing doesn't scroll properly, which makes everything clunky.

Some low hanging fruits would be, to replace drawing with TODOs and add one more icon in there, probably for [[Bidirectional linking]]

