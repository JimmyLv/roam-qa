[[September 21st, 2021]]

[[Customization]] #[[End User Programming]] #[[Quality of Life Improvements]]

Custom components in [[JSX]] and [[Javascript]]

{{[[video]]: https://grain.co/highlight/NkzVPjnoX3P8gavWAVq9g00DiABYGCE1gWZIU63J}}

[[Example]]

{{[[video]]: https://grain.co/highlight/2xiEAKKj5It1deDSFzbwWMbm3JXLwqt0OdtzmQ53}}

