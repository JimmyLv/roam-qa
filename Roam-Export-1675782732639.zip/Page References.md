Page references are links to [[Pages]] in your graph

You can reference an existing page by typing `[[`, which will open a dropdown menu with reference it in place or reference an existing page

All references to a page that have been linked through this method will appear in that pages [[Linked References]]

You can transform any mention of a page to a page reference by opening up the [[Unlinked References]] underneath where you can see and link all the mentions of a page that haven't been linked yet

Roam Team Videos::

{{[[video]]: https://www.youtube.com/watch?v=v9s3pusI1JQ}}

{{[[video]]: https://www.youtube.com/watch?v=lHkMq3aqDtw&ab_channel=ConorWhite-Sullivan}}

Community Videos::

Articles::

