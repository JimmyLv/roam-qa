The Block Context Menu is the menu that gets pulled up when you right click the circle bullets on any block, it brings up a list of common features you might need, these commands include:  

Team GIFs::

Toggling block context menu

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FrqEvtSIXXI.gif?alt=media&token=90085112-75bf-4ab3-aa92-a37bfbce372f)

Copy Block ref

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FtLOCTkDJmh.gif?alt=media&token=6b686749-3e4a-4809-9841-6b1e9703073c)

Focus on block

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FBtS-Wl25jF.gif?alt=media&token=a238e6c8-30e3-4a69-b60f-87499a6f4a68)

Open in Sidebar

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fw4RyQL5NLd.gif?alt=media&token=13659f0d-2c0c-4713-8b3a-de6a5edf7dfa)

Expand All

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FrzIXmWpaCv.gif?alt=media&token=be0bd209-0c50-43c5-b967-bd6ab81200ff)

Collapse all

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FABF_970huX.gif?alt=media&token=30b746a7-6213-48da-886c-e9d8cb455d80)

Add reaction

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FQLZYo7bsRj.gif?alt=media&token=e3c0ac44-f2eb-475f-889f-4605b89db241)

Make todo

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FmVnuTJLLlq.gif?alt=media&token=528fd198-da64-4a21-80c2-8bd6007ba018)

Add version

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FHNrxPTA3gs.gif?alt=media&token=ad1b8585-b52f-4356-b1b8-1aa109c5f7e3)

Delta (not really sure about this, added it in case it's needed)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F7vwTMYhLgA.gif?alt=media&token=3ac40f9a-f03b-4aef-a3f5-7e3e0f88800c)

View as Numbered list

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FXKIKHxUwZn.gif?alt=media&token=1290607c-b3e4-4ce2-a3bf-47afc371aaf9)

View as Document

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FtIl23mRzPT.gif?alt=media&token=0b09348e-e48a-45d3-b645-344d4a66f76c)

Alignment

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FNj8xa_j0-O.gif?alt=media&token=eef46bee-f56c-4974-b119-f87a14b11b2b)

Headings 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FCOTx6OZnuD.gif?alt=media&token=a3375edb-1083-4dbb-b5ac-042b7b91dbdc)

Roam Team Videos::

Mermaid diagrams combined with version control in Roam Research by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=UF22iK8fX-A&t}}
#[[Version Control]] | #[[Diagram]]

Articles::

[Programming your attention with Roam Research and ∆](https://elaptics.co.uk/journal/roam-research-programmable-attention/) by [[Elaptics]]

#[[Delta]] | #[[Spaced Repetition]] | #[[Programmable Attention]]

[Beyond Spaced Repetition: Δ in Roam Research](https://www.iantay.dev/post/beyond-spaced-repetition-%CE%B4-in-roam-research/) by [[Ian Tay]]

#[[Delta]] | #[[Spaced Repetition]] | #[[Programmable Attention]]

[A short (preliminary) guide to Spaced Repetition in Roam Research](https://www.cortexfutura.com/preliminary-spaced-repetition-roam/) by [[Cortex Futura]]

#[[Delta]] | #[[Spaced Repetition]] 

[Spaced Repetition in Roam Research](https://davidbieber.com/snippets/2021-01-02-spaced-repetition-in-roam-research/) by [[David Bieber]]

Community Videos::

Roam Research: Delta Feature by [[Les Kristofs]]

{{[[video]]: https://www.youtube.com/watch?v=2DkzqmidG54}}
#[[Delta]]

Concept of using Delta and Kanban for Time Management by [[RoamHacker]]

{{[[video]]: https://www.youtube.com/watch?v=sCGnWMqLteE}}
#[[Delta]] | #[[Kanban]]

Versions: Fundamentals of Roam Research by [[R.J. Nestor]]

{{[[video]]: https://www.youtube.com/watch?v=ryU0bMAz1zo}}
#[[Version Control]] 

Key Commands::

`⬅ Right click on the circle bullet`

