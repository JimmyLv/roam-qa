### Implementing a Digital Zettelkasten using Block References in Roam Research with [[Beau Haan]] by [[Robert Haisfield]]

{{[[video]]: https://www.youtube.com/watch?v=KoddCmn3eL0&ab_channel=RobertHaisfield}}
#[[Block References]] | #[[Page References]] | #[[Indentation]] | #[[Daily Notes]] | #[[Current time]] | #[[Right Sidebar]]

### Todoist to Roam Research - Advanced Task Management in Roam by [[Matt Goldenberg]]

{{[[video]]: https://www.youtube.com/watch?v=xOTTyLtgqpM}}
#[[roam/css]] | #[[Extensions]] | #[[roam/js]] | #[[Sidebar]] | #[[TODO/DONE]] | #[[Query]]

### A Beginner’s Guide to Roam Research by [[Drew Coffman]]

#[[Daily Notes]] 

{{[[video]]: https://www.youtube.com/watch?v=X6OOos4met0}}

### How I Organise My Life with Roam by [[Ali Abdaal]] 

#[[Daily Notes]] | #[[Bidirectional linking]] | #[[Linked References]] #[[Book]] | #[[Sidebar]] | #[[Tags]] | #[[Evergreen Notes]] | #[[Block References]] | #[[Templates]] | #[[Query]]

{{[[video]]: https://www.youtube.com/watch?v=bpikCLhpIRY}}


