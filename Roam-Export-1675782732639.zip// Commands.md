The / Commands give you access to a variety of functions in Roam

Key Commands:: 

To access / Commands, type `/` + `any of the below keyword` + `enter` (in any block) to access each feature 

Team GIFs::

![An example of accessing the TODO function via / Commands](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FoebmqUA8lT.gif?alt=media&token=0567d373-7f43-4934-9d92-c5f5030b6e42)


#.--rm-grid 

### **Functions**

[[TODO]]

[[Page References]]

[[Block References]]

[[Block Embed]]

[[Table]]

[[Diagram]]

[[Upload Files]]

[[Templates]]

[[Video Embed]]

[[Calculator]]

[[Mentions]]

[[Word count]]

[[Character count]]

[[Query]]

### **Time**

[[Current time]]

[[Today]]

[[Tomorrow]]

[[Date picker]]

[[Pomodoro timer]]

### [Formatting]([[Formatting]])

[[Links]]

[[Code Block]]

[[Inline Code]]

[[Bold]]

[[Italics]]

[[KaTeX]]

[[Strikethrough]]

