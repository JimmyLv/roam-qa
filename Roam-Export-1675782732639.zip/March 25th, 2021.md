https://twitter.com/Conaw/status/1375280053882253313?s=20

https://twitter.com/Conaw/status/1375287978482835468?s=20

[[Essay]] - [[Why you can't say]] [[Kevin Lacker]]

Response to:: [[Essay]] [[What You Can't Say]] [[Paul Graham]]

[[Tangent]]

See {{iframe:https://en.m.wikipedia.org/wiki/Social_constructionism}} 
and the idea of [[Roam Browser]] [[Electron App]]

When you visit the page - you could have an easy indicator -- like highlighting things from the page - (to pull into your Roam -- or spending a certain amount of time on it -- or a [[30ms Gesture]] like a moving the mouse in a pattern, or hitting a super easy keyboard shortcut -- and have the page be sent to [[ArWeave]] or [[Internet Archive]])

{{[[TODO]]}} Learn more about [[ArWeave]] -- catchup with [[Mek]] and [[Gerben]] and see what the current state of [[Web Archival]] is

it's been a few years -- but linkrot is huge problem - and one we should have easy answer for -- also could have options for global registries of these (or ipfs content hash the contnets (though content hash maybe maybe maybe has security concerns (probably moot if we have e2ee and you can choose what archival services you use...)))

