Community Videos::

### Roam Research: Notetaking Session for School by [[J M]]

{{[[video]]: https://www.youtube.com/watch?v=ZOWk76FhwEU&feature=youtu.be&ab_channel=JM}}
#[[Page References]] | #[[Indentation]] | #[[Right Sidebar]] 

### Roam for Students | How to Take Notes in a Lecture by [[Shu Omi]]

{{[[video]]: https://www.youtube.com/watch?v=nWgXBGDP3nI&ab_channel=ShuOmi}}
#[[Page References]] | #[[Indentation]]

### How I use Roam Research for Lecture Notes (for college students) by [[Abhinav Kejriwal]]

{{[[video]]: https://www.youtube.com/watch?v=gBYwBNY3pNc&ab_channel=AbhinavKejriwal}}
#[[Page References]] | #[[Sidebar]] | #[[Block References]]

## Articles::

### [How I Used Roam Research to Study for Medical School](https://toolsforgrowth.substack.com/p/how-i-used-roam-research-to-study)

#[[Daily Notes]] | #[[Page References]] | #[[Indentation]] | #[[Linked References]]

