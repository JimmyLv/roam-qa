## Get specialized 1:1 help to master Roam from one of our vetted coaches

[[Coaches]]

# [R.J. Nestor]([[R.J. Nestor]])

Info::

Business & Executive Coach, Musician, Writer

Helps you develop and optimize your Roam workflows

Created courses [Your Road to Roam](https://courses.rjnestor.com/p/your-road-to-roam) and [Powerful Task Management in Roam Research](https://courses.rjnestor.com/p/powerful-task-management-in-roam-research)

Website:: 

[roamcoaching.rjnestor.com](https://roamcoaching.rjnestor.com) [rjnestor.com](https://rjnestor.com) [youtube.com/c/rjnestorcoach](https://youtube.com/c/rjnestorcoach)

Areas of specialty::

[[Roam fundamentals]] ⬅ for ANY Roam skill level

[[Workflows]] [[Processes]]

[[Productivity]] [[GTD]]

[[Content creation]] [[Writing]] [[Creative writing]]

Contact::

DM on [Twitter](https://twitter.com/rjnestor)

Message through [Facebook coaching page](https://m.me/rjnestorcoach)

Price::

[Roam coaching packages](https://roamcoaching.rjnestor.com) start at $150

[DM](https://twitter.com/rjnestor) or [message](https://m.me/rjnestorcoach) for custom coaching package needs

# [Cortex Futura]([[Cortex Futura]]) 

Info::

PhD Student, Data Analyst, Teacher, Writer

Helps you

Created courses [Cite to Write](https://t.co/Z95EFrEenY?amp=1) (using Roam in academia) and Galaxy Brain (Algorithms of Thought)

Website::

[Coaching Website](https://learn.cortexfutura.com/p/roam-research-coaching?utm_source=roamresearch&utm_medium=graph&utm_campaign=helpgraph)

Areas of specialty::

[[Roam fundamentals]]

[[Workflows]]

[[Writing]], [[Publishing]]

[[Academia]]

Contact::

[DM on Twitter](https://twitter.com/cortexfutura)

coaching@cortexfutura.com

Price::

Roam Coaching Packages starting at $150

DM or message for custom coaching package needs

# [[Maarten van Doorn]]

Info::

PhD, Polymath, Tools for Thought Explorer, Essayist, Coach, Author

Helps you set up your personal Zettelkasten and smart notes workflow in Roam. You'll remember what you learn, discover new ideas and insights, turn your thoughts and discoveries into convincing written pieces, and build up a treasure of smart and interconnected notes along the way.

Wrote [The Complete Guide To Effective Note-Taking](https://roambrain.com/the-complete-guide-to-effective-note-taking/) and [The Complete Guide to Effective Reading](https://maartenvandoorn.medium.com/the-complete-guide-to-effective-reading-fc1835937757) (>300K reads). Created course [Academic Mastery with Roam Research](https://www.academicmasterywithroam.com/). 

Website::

[Coaching website](https://maartenvandoorn.com/roam-research-coaching/)

Areas of specialty::

[[Roam fundamentals]]

[[Effective Reading and Note-Taking in Roam Research]]

[[Information analysis]]

[[Academic writing]]

[[Popular writing]]

Contact::

[DM on Twitter](https://twitter.com/maartenvdoorn)

maarten@maartenvandoorn.nl

Price::

Get lifetime access to [Academic Mastery with Roam](https://www.academicmasterywithroam.com/) for $159.

[Coaching](https://maartenvandoorn.com/roam-research-coaching/) costs only $99 per one-hour 1:1 session, because I'm just an overachieving nerd who wants to help people :)

[DM](https://twitter.com/maartenvdoorn) or [message](mailto:maarten@maartenvandoorn.nl) for custom coaching package needs! I focus on the specific use case desired by you.

### [Request to be vetted](https://roamresearch.typeform.com/to/g5W8uCqz)

