[[.--]]

[[.--]]

## Team GIFs::

### Filter includes

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F0Mny65tH21.gif?alt=media&token=2f6a477f-7386-4bfb-b3e1-60ef67657814)

### Filter removes

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FC7VNv1Q5rE.gif?alt=media&token=9bd23efb-f1a5-4509-87d2-e7603c7ce9e8)

### Global filters

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FUrQg1RZrKl.gif?alt=media&token=27a5f9b8-606b-4239-85cf-b82fbee4167c)

### Filter linked references

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F3g-ykwQqW6.gif?alt=media&token=88eba400-5d2c-45f9-8093-a44513fc4a61)

## Roam Team Videos::

### Filters in Roam by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=BnwWdTnXlxU}}

## Community Videos::

### Filters: Fundamentals of Roam Research by [[R.J. Nestor]]

{{[[video]]: https://www.youtube.com/watch?v=wBqUySIvUZc}}
#[[Attributes]] | #[[Filter]] | #[[Linked References]] | #[[Tags]]

### How to use filters in Roam Research by [[Mickey Mellen]]

{{[[video]]: https://www.youtube.com/watch?v=hx9AmzNUCZY}}
#[[Attributes]] | #[[Filter]] | #[[Linked References]] | #[[Tags]]

## Articles::

### [How to use filters in Roam](https://www.roamtips.com/home/how-to-use-filters-in-roam) by [[Roam Tips and Hacks]]

### [Using Roam Research for GTD-Style Task Management](https://thesweetsetup.com/using-roam-research-for-gtd-style-task-management/) by [[Mike Schmitz]]

