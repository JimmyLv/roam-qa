Encrypted block creates encrypted text that can only be unlocked with a secret password

Try clicking on the encrypted block below, and enter the passphrase `hello`

{{encrypt:U2FsdGVkX19S1e0ybaJH2keLGMifvVhqsBlVINdMpvPegcL01PWU6gjltQgbMGwzLoZWQdzrejJ8tJFNKIjNAUfBZ2o4d5XVpZRhDyICt8DoDCbPD65ATX9HHfM4Oa72zxv5jKUESYe0xku/Yqj3Lg==}}

## Roam Team Videos::

https://twitter.com/i/status/1226658292333568003

