Community Videos::

### Roam Research Tutorials by [[Shuyi Wang]]

{{[[video]]: https://www.youtube.com/watch?v=TXKa0VbQZeY&list=PL-BErONJz2qEEUS3OjpuWHhtb9JjXKFBZ&index=2}}
#[[Page References]] | #[[Bidirectional linking]] | #[[Block References]] | #[[Linked References]] | #[[Graph Overview]]

### 用Roam Research做唸書筆記：以民法總則為例 by [[yang Scicily]]

{{[[video]]: https://www.youtube.com/watch?v=Ic3Ens2DJzs&feature=youtu.be}}
#[[Graph Overview]] | #[[Sidebar]] | #[[Page References]]

### Roam教學:第一集(Otter.ai與otter2roam的運用) by [[曹建雄]]

{{[[video]]: https://www.youtube.com/watch?v=W2CkfWkxluo}}
#[[Upload Files]] | #[[Audio Player]] | #[[Video Embed]] | #[[otter2roam]]

