Key Things to Know

Open by pressing `Ctrl+Shift+9` while focused on a block

`Tab` or `Enter` will add an item to the path or—when there is no text in the search field—select the block and ref it in the focused block

`Delete` will move you back up the path

Use Cases::

Placing new items on another page, then referencing them in your current context

Without breaking flow

