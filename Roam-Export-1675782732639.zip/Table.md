[[.--]]

{{[[table]]}}

## Articles::

[How to build a table in Roam Research](https://web.archive.org/web/20201109133038/https://www.roamtips.com/home/create-tables-roam-research) - [[Roam Tips and Hacks]] 

## Community Videos::

### How to Set Goals Using Tables in Roam Research by [[Shu Omi]]

{{[[video]]: https://www.youtube.com/watch?v=CPk5RSnlpDA}}

### Roam Research: Tables by [[Les Kristofs]]

{{[[video]]: https://www.youtube.com/watch?v=nZHlz6RUleE}}

## Roam Team Videos::

### Tables with Complex Cells (no audio) by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=J_hH5vH2DTo}}
#[[Table]]

[[.--]]

