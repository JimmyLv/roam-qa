## Community Videos::

### Processing Sermon/Bible Notes Using Roam Research by [[Mickey Mellen]]

{{[[video]]: https://www.youtube.com/watch?v=nplokaE6FKY&ab_channel=MickeyMellen}}
#[[Page References]] | #[[Linked References]] | #[[Graph Overview]] | #[[Block References]] | #[[Sidebar]]

## Articles::

### [How I’m Using Roam Research for Bible Study](https://thesweetsetup.com/how-im-using-roam-research-for-bible-study/) by [[Josh Ginter]]

#[[Graph Overview]] | #[[Date picker]] | #[[Upload Files]] | #[[Markdown]] | #[[Page References]] | #[[Block References]]

### [Processing sermon and Bible notes using Roam](https://www.roambrain.com/processing-sermon-and-bible-notes-using-roam/) by [[Mickey Mellen]]

#[[Page References]] | #[[Linked References]] | #[[Graph Overview]] | #[[Block References]] | #[[Sidebar]]

