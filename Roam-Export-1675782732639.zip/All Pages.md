### Delete pages

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FYqxqKorQI-.gif?alt=media&token=736383b1-77c5-43d0-afe0-1b9559750dad)

### Export pages

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FpUjhHuw3Mc.gif?alt=media&token=9caee6c3-dcbb-4c43-89d4-45bf71df39d8)

### Open pages from all pages in right sidebar

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FDcJ5GFlnvx.gif?alt=media&token=ee49c2a4-5933-4ac8-9feb-15bb5cc3c8ad)

### Sort by word count

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FV226Qy7Jn4.gif?alt=media&token=59c28d94-b911-400e-b845-9f6bcd0a05b8)

### Sort by mentions

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F4TA971JxG9.gif?alt=media&token=8c202935-ef44-4900-a8e7-ab9f09889382)

### Sort by updated

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FmPIx1RBFdI.gif?alt=media&token=163433ca-ac63-4136-ba7d-29115c359dfe)

### Sort by created

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FaOtImawJYl.gif?alt=media&token=7e17d57a-4abd-4034-aa27-3224f722967b)

### Show/hide daily notes

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FPfwk0lp1br.gif?alt=media&token=a49684ef-d8ba-4e19-b2d3-deb8889eb9f0)

### Show/hide columns

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F4Qv1CNFt4D.gif?alt=media&token=21c2a442-8ac3-4ca3-9cad-0c00322812a9)

