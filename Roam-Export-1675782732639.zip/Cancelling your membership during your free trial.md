**Step 1.** Sign in to your Roam account, with the email address you used at sign up:

![](https://s3.amazonaws.com/cdn.freshdesk.com/data/helpdesk/attachments/production/64002070371/original/MMXLJ-K6hZckTp4vb2ugeG84ea1Ta20NZA.png?1598331956)

**Step 2. **Click on the 'Click here' link at the top of screen:

![](https://s3.amazonaws.com/cdn.freshdesk.com/data/helpdesk/attachments/production/64002070384/original/6TXbdTfJDSi8Kln2TueD6_piIvjSoj_s-A.png?1598332029)

**Step 3. **Click the cancel plan button on screen:

![](https://s3.amazonaws.com/cdn.freshdesk.com/data/helpdesk/attachments/production/64002070441/original/txb0rHyrlhlnEQ_Av_CeNfgxDLNwpgyHiQ.png?1598332198)

This will cancel your trial.  If you have any problems at all, please contact Roam support. We can also cancel your plan manually on your behalf well.

Thanks for trying Roam!

