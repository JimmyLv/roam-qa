If you're used to clicking hyperlinks when browsing the web, you already know how to navigate in Roam! Click on any page reference or external link, and you'll be taken to the desired destination :)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F-yQdrK2WEG.gif?alt=media&token=5c188f8f-3fc2-43d8-b965-6387e0ac3ad1)

Roam also offers a variety of navigation shortcuts that allow you to speed up your workflow - here are some of the most important ones: 

**Zooming in and out of blocks**

With your cursor placed on a block, hit the following keys to zoom in or out of that block - 

**Mac: **

Focus in: `Cmd+Shift+Period`

Focus out: `Cmd+Shift+Comma`

**Windows: **

Focus in: `Alt+Right`

Focus out: `Alt+Left`

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FtqHirgtMO_.gif?alt=media&token=87357662-1a08-4b67-b85f-d0c224182b7a)

**Focusing in on blocks**

Focusing on a block couldn't be easier: just click on the bullet!

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FYgAwR6TLsr.gif?alt=media&token=3bd61b2d-d661-47f9-8679-f5beedcee236)

Key Commands::

`Cmd+Shift+Period` [*](((Pk8lkM2_w))) on Mac

`Alt+Right` [*](((nOWIuCsv8))) on Windows

**Opening breadcrumbs**

Your recently opened pages and blocks are available from the search bar under the "Recent" Section. Here's an example: 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Ff9lWrKeukf.gif?alt=media&token=7c43fb1a-b505-44ad-b3d2-2c6cfdbf9219)

Key Commands::

`Cmd+u` on Mac

`Ctrl+u` on Windows

**Back and forward**

Roam takes advantage of browser navigation shortcuts to allow you to go forward and back. 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FfT-l8KNveN.gif?alt=media&token=083c01d8-476f-43b3-bdbe-d812b7499bc0)

Key Commands::

`Cmd+Right` and `Cmd+Left` on Mac

`Ctrl+Right` and `Ctrl+Left` on Windows

**Opening blocks and pages in sidebar**

Open **anything** in the sidebar by shift-clicking it!

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FnGag3VEJSH.gif?alt=media&token=89c4f99e-90f8-4d5f-a68d-e82fdd8eb57d)

Key Commands::

`Shift+click` on any pages, block references, etc

**Go to Daily notes**

To go back to the Daily Notes view, open the left sidebar and click on "Daily Notes"

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FcYeZw71gEA.gif?alt=media&token=6c32504f-4f8d-4841-8840-8cd7adb5dc8d)

Key Commands::

`Ctrl+shift+d` on Mac

`Alt+d` on Windows

**Go to next day / previous day**

From a Daily Note page, hitting these key commands will take you to the previous and the next day! 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F2a6LfUawVz.gif?alt=media&token=9ddc91b2-bb1c-4816-8c1f-c25be57e273b)

Key Commands::

`Ctrl+alt+p` and `Ctrl+alt+n` 

**Go to first / last block on page**

With your blocks in reading mode (i.e when the cursor is not blinking on any block), hitting these commands will place the cursor on the first block of the page or to the last block of the page.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F-NGwXfmjDz.gif?alt=media&token=2ccbebf6-f89a-4ad8-a391-13010ccf95d2)

Key Commands::

`Cmd+enter`and `Cmd+shift+enter` on Mac

`Ctrl+enter` and `Ctrl+shift+enter` on Windows

**Follow a link under cursor**

If your cursor is placed on a linked reference, hitting these commands will open the link. 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FduTr5hTjZt.gif?alt=media&token=c5c26287-9df1-4472-921f-c6b4af4f154e)

Key Commands::

`Ctrl+o`

**Open a link under cursor in the sidebar**

If your cursor is placed on a linked reference, these key commands will open the link in the sidebar!

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FsvakjNFVH8.gif?alt=media&token=157c7665-5c95-4a55-ba86-879a4c1ad1dc)

Key Commands::

`Ctrl+Shift+o`

**Jump to the start and end of a block**

With your cursor on a block (edit mode) hitting these key commands will place the cursor at the beginning and end of the block.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FEDvGeabLez.gif?alt=media&token=92c2ee8a-6da2-41f2-b018-46daf4b3fa71)

Key Commands::

`Ctrl+a` and `Ctrl+e` on Mac

`Ctrl+home` and `Ctrl+end` on Windows

