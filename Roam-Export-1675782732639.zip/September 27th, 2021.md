[[September 27th, 2021]]

[[Quality of Life Improvements]] ✨

Added a shortcut (`Cmd/Ctrl+Opt+R`) to toggle [[Youtube]] [[Videos]] playback while typing in a block

Made [[Video Timestamps]] look a little nicer

[[Bug Fixes]]  🛠

Fixed bug that caused Roam to crash when [[Query]] using `between` contained only one date

