## Team GIFS::

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FGTJJMUaPJd.gif?alt=media&token=c47571e2-1ab0-4271-b6bd-10dc0764ebc9)
#[[roam/templates]]

## Community Videos::

### How to create templates in Roam Research by [[Productivity Academy]]

{{[[video]]: https://www.youtube.com/watch?v=O_-lhwprLXs}}
#[[Templates]] | #[[Attributes]] | #[[Sidebar]]

### Daily Templates in Roam Research by [[Mickey Mellen]]

{{[[video]]: https://www.youtube.com/watch?v=mK7wa0UXzrk}}
#[[Templates]] | #[[Task Management]] | #[[Current time]] | #[[Tags]]

### Native Templates In Roam Research by [[Praveen Anuraj]]

{{[[video]]: https://www.youtube.com/watch?v=OxCgJaeUh90}}
#[[Attributes]] | #[[Templates]]

## Articles::

### [How to use templates in Roam Research](https://nesslabs.com/roam-research-templates-tutorial) by [[Anne-Laure Le Cunff]]

### [How to Create and Use Templates in Roam Research](https://www.appsntips.com/learn/create-use-templates-roam-research/) by [[appsntips]]

## Key Commands::

Search for template to trigger `;;`

