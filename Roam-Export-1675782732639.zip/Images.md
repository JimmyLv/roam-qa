You can include images on Roam in these two ways

Pull from the internet (nothing gets stored, so if original link is broken, you lose the [image](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FE5b-pBgXuQ.png?alt=media&token=b29c9beb-f9f3-44c7-88db-42a6b2b32289))

![image](https://res-1.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_170,w_170,f_auto,b_white,q_auto:eco/kop5qscevpniah2rbsfb)

Upload from your local computer (the image gets uploaded to our server)

Team GIFs::

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fp8y1UIR1C0.gif?alt=media&token=b7b763f2-b5f6-4e37-a015-0053dc0bf63c)

`/upload` to upload from your local computer
#[[Key Commands]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp%2Fk6NvrFcN0y.gif?alt=media&token=2983eb2f-ccd4-4d0c-beed-a386bfc5a614)

Highlight a word, press `Cmd+k or Ctrl+k`, paste the image link
#[[Key Commands]]

Key Commands::

`![image](yourimageurl.com)` to pull from the internt

