Calculates basic arithmetic. 

`{{calc: 4 + 5 }}`

{{calc: 4 + 5}}

If a block reference is used an argument, it will search for a number in that block and use that – e.g.

three in “My 3 apples” or

five in "his 5 amazon stocks"

`{{calc: ((block)) + ((block)) * 2 }}`

{{calc: ((7JA7DJvAp)) + ((f1EhaKxmC)) * 2}}

## Community Videos::

### [Roam Research: Using the Calculator](https://www.youtube.com/watch?v=kxWykFHUtNo) - [[Les Kristofs]]

{{[[video]]: https://www.youtube.com/watch?v=kxWykFHUtNo}}

## Roam Team Videos::

https://twitter.com/i/status/1209449973902802944

