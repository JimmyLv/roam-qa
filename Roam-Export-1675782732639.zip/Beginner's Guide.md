# A short but comprehensive guide

### A Beginner’s Guide to Roam Research by [[Drew Coffman]]

{{[[video]]: https://www.youtube.com/watch?v=X6OOos4met0}}


#[[Daily Notes]] | #[[/ Commands]] | #[[Bidirectional linking]]

# [[Why Roam?]]

### Leonardo Da Vinci and Roam-Thinking by [[Drew Coffman]]

{{[[video]]: https://www.youtube.com/watch?v=S3qJdvPzOC8}}


# Best [[Features]] of Roam

### The Simple Guide to Roam Research by [[Shu Omi]]

{{[[video]]: https://www.youtube.com/watch?v=RTI6Mxu3YiI}}


#[[Daily Notes]] | #[[Bidirectional linking]]

# What [[Workflows]] can I use Roam for?

### What's So Great About Roam Research? by [[Nat Eliason]] 

{{[[video]]: https://www.youtube.com/watch?v=syKAar8ZD-U}}


#[[Daily Notes]] | #[[Bidirectional linking]] | #[[Linked References]] #[[Book]] | #[[Sidebar]] | #[[Tags]] | #[[Evergreen Notes]] | #[[Block References]] | #[[Templates]] | #[[Query]]

