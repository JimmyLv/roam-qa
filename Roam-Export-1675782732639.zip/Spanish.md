### ✏️Cómo TOMAR NOTAS con ROAM RESEARCH & ZETTELKASTEN | Tutorial en español by [[Emowe Aprendizaje]]

{{[[video]]: https://www.youtube.com/watch?v=bwpVWyOBjHw}}
#[[Daily Notes]] | #[[Page References]] | #[[Formatting]] | #[[Graph Overview]] | #[[Right Sidebar]] | #[[Linked References]] | #[[Navigation]] | #[[Block References]] | #[[Block Embed]] 

---

### [Curso Roamresearch "Beta"](https://www.youtube.com/playlist?list=PL2CI0VRuaLWcDOU6RQLVJQb6lwW4QRqAN) | by [[Jorge Arone]]

#Courses

---

### [Curso Roamresearch "Avanzado"](https://www.youtube.com/playlist?list=PL2CI0VRuaLWchGZi3KZOwvwqPNDGBicXP) | by [[Jorge Arone]]

#Courses

