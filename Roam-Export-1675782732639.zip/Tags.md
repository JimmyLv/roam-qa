Tags are just [[Page References]] that are styled a bit differently (light grey font color) so that the tag is not as prominent

Usually used at the end of blocks or at the beginning, whereas normally [[Page References]] are used alone as parent block or inline as part of a sentence

Key Commands::

`#` to find or create [[Page References]] as a [tag]([[Tags]])

