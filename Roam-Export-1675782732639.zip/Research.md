## Roam Team Videos::

### Roam for Research by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=L6GIW4PprQE&t=17s&ab_channel=ConorWhite-Sullivan}}
#[[Page References]] | #[[Linked References]] | #[[Unlinked References]] | #[[Right Sidebar]] | #[[Block References]]

## Community Videos::

### How I Use Roam for Academic Research by [[Notes with Ren]]

{{[[video]]: https://www.youtube.com/watch?v=JvoSiVolPko&t=7s&ab_channel=NotesWithRen}}
#[[Page References]] | #[[Images]] | #[[Indentation]] | #[[Daily Notes]] 

### How to Use Roam Research Attributes for Academic Reference Management by [[Nabhan]]

{{[[video]]: https://www.youtube.com/watch?v=7A_KMK4qILo&ab_channel=Nabhan}}
#[[Query]] | #[[Page References]] | #[[Attributes]] | #[[Indentation]] 

## Articles::

### [In search of the Literature X-ray: Using Roam in academic research](https://www.roambrain.com/in-search-of-the-literature-x-ray/) by [[Cortex Futura]]

#[[Query]] | #[[Page References]] | #[[Alias]] 

