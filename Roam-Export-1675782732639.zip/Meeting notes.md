## Community Videos::

### Mini CRM in Roam Research: Logging meeting notes by [[R.J. Nestor]]

{{[[video]]: https://www.youtube.com/watch?v=CnakhkONQ_g&t=6s&ab_channel=R.J.Nestor}}
#[[Daily Notes]] | #[[Tags]] | #[[Indentation]] | #[[Linked References]] | #[[Filter]] | #[[Right Sidebar]]

## Roam Team Videos::

### Meeting Notes in Roam by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=wMOOU8uFLZI&t=129s&ab_channel=ConorWhite-Sullivan}}
#[[Page References]] | #[[Daily Notes]] | #[[Date picker]] | #[[Linked References]] | #[[TODO/DONE]] | #[[Right Sidebar]] | #[[Filter]] | #[[Query]] | #[[Block References]] | #[[Alias]]

### Taking Notes on 1:1s by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=otoF_ane688&ab_channel=ConorWhite-Sullivan}} #[[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=otoF_ane688&ab_channel=ConorWhite-Sullivan}}
#[[Current time]] | #[[Page References]] | #[[Right Sidebar]] | #[[Linked References]] | #[[Query]] | #[[TODO/DONE]] | #[[Block References]] 



