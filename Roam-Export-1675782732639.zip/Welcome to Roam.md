Getting startedℹ️ (hint... shift-click the links in blue below 😉) #.box

[Show me some video tutorials on where to begin]([[Beginner's Guide]])

### [How to link your notes]([[Bidirectional linking]])

### [How to format your text]([[Formatting]])

### [How to work with several notes at a time with the right sidebar]([[Right Sidebar]])

Type `/` into a block to check out features available in the [[/ Commands]] menu

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fvg4SUhgwIf.gif?alt=media&token=f4f682cb-e612-447a-83c1-9f4934818eaa)

> Here are [some amazing free courses](((eEUXylm_o))) from our [community]([[Community]])

[[Workflows]]

Roam is a tool geared for [[Writing]], [[Research]], and [[Studying]]

It can also be used for [task]([[Task Management]]) and [project management]([[Project Management]]) or even as a [[Personal CRM]]

Roam is highly flexible and our community discovers new [[Workflows]] it can support every day

Still have questions?

Check out [this page]([[Features]]) to see an overview of all the **features** available in Roam

You should also join our [Slack](https://join.slack.com/t/roamresearch/shared_invite/zt-xy0pd90x-c0KDkgh1BeLKyi0iUlJ1CA), where our amazing community shares resources, workflows, tips, tricks, and more

If you want to learn more about why Roam is __different__, see [[Why Roam?]]

And if you really want to geek out, you should read our [[White Paper]]

