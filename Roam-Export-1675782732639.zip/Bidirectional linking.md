It doesn't matter what [page]([[Pages]]) you've written a note on, if you mention an idea, every place where you mentioned that idea will get collected underneath that page in the [[Linked References]] section when you turn turn that idea into a [page reference]([[Page References]])

Roam Team Videos::

{{[[video]]: https://www.youtube.com/watch?v=v9s3pusI1JQ}}

{{[[video]]: https://www.youtube.com/watch?v=lHkMq3aqDtw&ab_channel=ConorWhite-Sullivan}}

Articles::

[A Short History of Bi-Directional Links](https://maggieappleton.com/bidirectionals) by [[Maggie Appleton]]

Key Commands::

`[[` to find or create [[Page References]]

`cmd+u` (macOS) / `ctrl+u` (PC) to [[Find or create page]]

`#` to find or create [[Page References]] as a [tag]([[Tags]])

