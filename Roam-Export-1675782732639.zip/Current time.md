Current time displays the current time in your time zone, it's great for tracking time while writing daily logs 

For example

21:19

Task Management by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=3aCl7dCYVqA&t=6s&ab_channel=ConorWhite-Sullivan}}
#[[TODO/DONE]] | #[[Daily Notes]] | #[[Filter]] | #[[Linked References]] | #[[Block Embed]] | #[[Current time]] | #[[Block References]]

Key Commands::

`/time`

