Mentions help you pull information (i.e., References) right on any [[Blocks]], without you having to open extra windows or sidebars to access them

For example, pulling the mentions for the [[Linked References]] and [[Unlinked References]] for White Paper

{{[[mentions]]: [[White Paper]]}}

Community Videos::

How To Use Roam Research Basics: Mentions and Using It With Daily To Dos or Task Management by [[The Upgraded Brain]]

{{[[video]]: https://www.youtube.com/watch?v=5zC0EEeeMX0}}
#[[Task Management]] | #[[Mentions]] | #[[Task Management]]

Articles::

[What are page mentions and block mentions in Roam?](https://www.roamtips.com/home/page-mentions-and-block-mentions-roam) by [[Roam Tips]]

#[[/ Commands]] | #[[Mentions]]

Key Commands::

`/mentions`

