To capture console logs

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FtJGk8RLQBL.gif?alt=media&token=1aca0f27-de62-4661-8e02-37b4fcd4ccea)

Right click your Roam screen

Click "Inspect"

Click "Console"

Right click anywhere in the console logs

Click "Save as"

Save

