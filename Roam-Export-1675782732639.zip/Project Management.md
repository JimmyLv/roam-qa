## Community Videos::

### Managing tasks and projects with Roam Research by [[Mickey Mellen]]


{{[[video]]: https://www.youtube.com/watch?v=NoNebWRn9ZQ&ab_channel=MickeyMellen}}
#[[TODO/DONE]] | #[[Page References]] | #[[Daily Notes]] | #[[Linked References]] | #[[Date picker]] | #[[Filter]] 

### PARA in Roam Reserach, Managing projects and tasks by [[Praveen Anuraj]]


{{[[video]]: https://www.youtube.com/watch?v=SQ71uG1q79g&ab_channel=PraveenAnuraj}}
#[[Page References]] | #[[TODO/DONE]] | #[[Query]] | #[[Date picker]] 

## Articles::

### [How I’m using Roam Research to Document a Sales Project | by Eran Boodnero | Medium](https://medium.com/@eboodnero/how-i-became-a-productivity-power-house-9da20ba728c0)

#[[Page References]] | #[[TODO/DONE]] | #[[Block References]] | #[[Daily Notes]] 

### [Project management for people who like flow and hate project management – Joshua Mitchell](https://lelon.io/blog/roam-research-project-management)

#[[Page References]] | #[[TODO/DONE]] | #[[Current time]] | #[[Right Sidebar]] | #[[Linked References]] | #[[Search]] 

### [Tasks and notes: A match made in Roam - R.J. Nestor](https://rjnestor.com/home/tasks-and-notes-a-match-made-in-roam/)

#[[Page References]] | #[[Query]] | #[[Block References]] | #[[Replace With]] |  #[[text and alias]] | #[[TODO/DONE]]



