How is Roam like Excel by [[Conor White-Sullivan]]

{{[[video]]: https://www.youtube.com/watch?v=mlCiO2oIF2s}}

