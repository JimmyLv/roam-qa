# We have a thriving community on Slack! 

# Join via [this link](https://join.slack.com/t/roamresearch/shared_invite/zt-xy0pd90x-c0KDkgh1BeLKyi0iUlJ1CA)

## We've got a curated graph of content of important things, accessible [here](https://roamresearch.com/#/app/roam-slack)

### If you'd like access to the archive, fill out [this form](https://docs.google.com/forms/d/e/1FAIpQLSc8SpE4UOr2UynEqk-2Ob9TZECQaYGNO6XksphxqVPH2HosmQ/viewform)

