# [[Fundamentals]] 

### [[Bidirectional linking]]

It doesn't matter what [page]([[Pages]]) you've written a note on, if you mention an idea, every place where you mentioned that idea will get collected underneath that page in the [[Linked References]] section when you turn turn that idea into a [page reference]([[Page References]])

Roam Team Videos::

{{[[video]]: https://www.youtube.com/watch?v=v9s3pusI1JQ}}

{{[[video]]: https://www.youtube.com/watch?v=lHkMq3aqDtw&ab_channel=ConorWhite-Sullivan}}

Articles::

[A Short History of Bi-Directional Links](https://maggieappleton.com/bidirectionals) by [[Maggie Appleton]]

Key Commands::

`[[` to find or create [[Page References]]

`cmd+u` (macOS) / `ctrl+u` (PC) to [[Find or create page]]

`#` to find or create [[Page References]] as a [tag]([[Tags]])

### [Navigation]([[Navigation]])

### [Formatting]([[Formatting]])

### [Search]([[Search]])

### [Key Commands]([[Key Commands]])

# **Components** #.rm-grid

## Basic

### [[Blocks]]

### [Pages]([[Pages]])

### [[Right Sidebar]]

### [[/ Commands]]

### [[Daily Notes]]

### [[TODO/DONE]]

### [[Templates]]

### [[Command Palette]]

## Advanced

### [[Filter]]

### [[Kanban]]

### [[Table]]

### [[Query]]

### [[Slider]]

### [[Calculator]]

### [[Encrypted Block]]

## Other

### [Left Sidebar]([[Left Sidebar]])

### [Reactions]([[Reactions]])

### [Graphs and Settings]([[Graphs and Settings]])

### [All Pages]([[All Pages]])

### [Graph Overview]([[Graph Overview]])

### [Sharing]([[Sharing]])

### [Import]([[Import]])

### [Export]([[Export]])

# **Extend** #.rm-grid [🚧](((dmQooXFj9)))

### [[roam/js]] 

### [[roam/css]]

### [[roam/render]]



