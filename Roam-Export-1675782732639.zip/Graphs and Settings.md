## Team GIFs::

### Access from

### Dropdown menu to access graphs

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FeFf25Fq_-A.gif?alt=media&token=f8a7adc0-6992-4b9e-9b1b-75ef0f209220)



### URL

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Frx9XKw3a1I.gif?alt=media&token=b68a9063-4324-4d54-8b79-206af1e2a7d8)



### Sign up for a plan

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F_m1ogNTpFh.gif?alt=media&token=abfa8703-db04-4011-ada1-48220ed1e95b)



### Upgrade to believer flow

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FnM5wcOhskc.gif?alt=media&token=40ad89ee-40f3-4de9-8eb4-7281afa3f789)



### Create new [[Graph]]

### [[Hosted Graph]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fi8T4ru8TAo.gif?alt=media&token=de655cc0-889b-4735-a01c-8d34e5ad3103)

### [[Local Graph]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FUKPFUwGlCg.gif?alt=media&token=5e551237-29da-43ef-bd77-160795d51ca9)



### View all graphs

### Via [[Left Sidebar]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FTba8Z2P_xZ.gif?alt=media&token=b1ab3dc4-f818-44ab-8dc6-4970b291c4e6)



### Via [[Graphs and Settings]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FIAhXgt0D7b.gif?alt=media&token=be9f1773-5c61-472c-b207-5fb485a0a461)



### Chat with us through the live chat button

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fp4j-x7Aw90.gif?alt=media&token=25df2c65-6b47-4a57-92c0-a9acb496ff31)



### Sign out

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FJuTSrhqxQx.gif?alt=media&token=c73c6912-9e3c-48dd-9111-641281349170)



### Cancel subscription

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FDZYkxL9L-C.gif?alt=media&token=31fb02dc-6d1c-4151-9b79-e6c3f6de465f)

# What do the different icons mean?

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FxCqTuAU4P9.png?alt=media&token=b4925722-3d54-4427-b3b6-161c796c70c6)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FzsUfoJTbkf.png?alt=media&token=81382a9e-b7e9-4d1e-88ae-67182c9e16a2)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F7o2QsjtwRI.png?alt=media&token=35d74526-bc71-4323-8e57-58bf6cb99416)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FkPbJKWltY6.png?alt=media&token=d53ba3db-d911-4cd0-9692-e26bec4d55de)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FE_gU_n8QSX.png?alt=media&token=29d8a866-5692-4963-941f-1231b1836447)

