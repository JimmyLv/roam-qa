### **Does Roam have a mobile app? Can I install it on my machine?**

Not yet, however Roam is available now as a webapp which gives you full access to your Roam and functions in a similar way to an app available through the appstore.

Here's how to install Roam as a webapp on your **phone** or **tablet**:

Go to chrome (or the other browser you use such as safari, firefox etc), then go to [http://www.roamresearch.com](http://www.roamresearch.com/), and it will ask you to sign in to your Roam account.

Once you sign in you will see this screen below. And then click the prompt at the bottom that says 'Add Roam to homescreen', which will install Roam as a link on your tablet/phone.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Froam%2FALLP4qNh6G.png?alt=media&token=83f0d3f8-9d42-4016-b83b-4c29816cb2a1)

An alternative way to do this, if you go to [roamresearch.com](http://roamresearch.com/) and sign in, you should should see 'install full site' as a button on the top right of page, if you click this it will install Roam on your device.

Here's how to install Roam as a webapp on your **desktop**: 

Go to Chrome, and open your Roam graph

From Chrome's three-dot-menu, go to "More Tools", "Create Shortcut"

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fq2dKP-MzXc.gif?alt=media&token=801dbe63-be9d-4d89-84cf-0c2ab85e3066)

More on this: https://www.roamtips.com/home/roam-research-app-mac-windows

