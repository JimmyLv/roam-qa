### Importing [[JSON]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fc7Lo7AEKTW.gif?alt=media&token=30f458c8-7c5e-4777-8e7d-d1324f6453a6)

### Importing [[Markdown]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FqVCxXBjzNU.gif?alt=media&token=7f3f8124-9e32-486d-9e3d-c004598f346c)

### Restore your entire graph from [[EDN]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FSgFSQeP1DW.gif?alt=media&token=55c8c34e-1028-4442-8744-7268d4e3a002)

