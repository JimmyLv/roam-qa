Restore your entire graph from [[EDN]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FSgFSQeP1DW.gif?alt=media&token=55c8c34e-1028-4442-8744-7268d4e3a002)

