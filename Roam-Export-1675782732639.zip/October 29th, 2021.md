{{[[query]]: {and: [[ex-A]] [[ex-B]]}}}

