source:: https://lamport.azurewebsites.net/pubs/proof.pdf



