[[Roam Slack ]]

[Join us on Slack](https://join.slack.com/t/roamresearch/shared_invite/zt-ni1vw9yf-HzeWr05ZJBt55j_zfddPsw) to learn new workflows, get tips and tricks from your fellow Roamans, and much more!

[[Twitter]]

Join the [#roamcult](https://twitter.com/search?q=%23roamcult&src=typeahead_click) and keep up to date with all the latest and greatest in Roam

[[Roam Book Club]]

Learn how to use Roam, take better notes, make friends, and more

[[Articles]]

An (incomplete) list of all the articles written about Roam!

[[Community Videos]]

A list of all the great videos made by our wonderful community

[[Courses]]

Learn how to use Roam with a collection of free and paid online courses made by top community members

[[Coaching]]

Get specialized 1:1 help to master Roam from one of our vetted coaches

[Notable Graphs]([[Notable Graphs]])

A list of public graphs available to browse or contribute to

