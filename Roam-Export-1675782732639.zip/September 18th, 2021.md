[[September 18th, 2021]]

[[Customization]] [[Improvements]]

Styling changes applied to blocks via `#.style-tags-like-this` now propogate to references of those blocks red #.bg-red-500  #.text-white , white and blue #.bg-blue-500 #.text-white 

white

blue #.bg-blue-500 #.text-white 

red #.bg-red-500  #.text-white 

Propogates many levels up too -- see ((((q_CXURfgB)))) 

