### Sharing graph as read-only

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2Fzku2IXzUiI.gif?alt=media&token=169f61f6-e752-48a0-832f-2fbc13b84352)



### Sharing graph as publicly editable

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F3WqdnWRZwg.gif?alt=media&token=63ee15ac-a74c-485a-9300-720497a5c2b9)

### Sharing graph with specific editors

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2FY-FPojuhvr.gif?alt=media&token=5380268f-65f5-41b6-ad41-03f21f118bac)

### Sharing graph with specific readers

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp-documentation%2F3Y6w9oqp9k.gif?alt=media&token=1295e3f2-0936-43ff-915b-243845477fe2)

