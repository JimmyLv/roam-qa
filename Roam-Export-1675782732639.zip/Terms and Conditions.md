### **TLDR: **Roam does not own your data, nor do we sell it to others or use it for advertising. We will never read or access your private notes without written or verbal consent - unless compelled by law enforcement.

### Article 1. Introduction

The following describes the terms upon which Roam Research, Inc. offers you access to our services. By clicking “Join Now,” “Join Roam,” “Sign Up” or similar, registering, accessing or using our services (including, but not limited to, www.roamresearch.com and the Roam mobile site, and all other Roam websites, apps, developer platforms, management and transaction services, premium services, other products and services offered by Roam, or any content or information provided as part of these services, collectively, the “**Services**”), you are entering into a legally binding agreement (either individually or on behalf of an entity).

These Terms and Conditions include the Roam User Agreement, the Roam Terms of Service, the Roam [[Privacy Policy]], and other terms that will be displayed to you at the time you first use certain features or services, all of which may be amended by Roam from time to time. Roam shall provide notice by email, to the email address on file in User’s Roam account at the time of notice, if substantive changes are made to the Roam User Agreement, the Roam Terms of Service, or the Privacy Policy. After such notice has been provided, continued use of the Services constitutes understanding and acceptance of the revised and amended Terms and Conditions.

These Terms and Conditions apply to both registered “**Members**” and unregistered “**Visitors**” for use of the Roam website and of the Roam Services. Both Members and Visitors are hereinafter referred to as “**User(s)**”.

### Article 2. Roam User Agreement

This User Agreement (the “**Agreement**”) is entered into by and between a user of Roam (hereinafter, “**User**”) and Roam Research, Inc, (hereinafter, “**Roam**”), a Delaware corporation (User and Roam are hereinafter individually referred to as a “**Party**” or collectively referred to as the “**Parties**”). This User Agreement applies to any and all Users of Roam, and specifies the general terms by which Roam offers its services to its users.

**I. Using Roam.**

While using Roam, User agrees that it will not: 

Violate any laws, third party rights, or Roam’s [[Privacy Policy]]; 

Circumvent or manipulate Roam’s Fee structure, the billing process, or Fees owed to Roam;

Post or otherwise disseminate false, inaccurate, misleading, defamatory, or libelous content (including personal information);

Transfer User’s Roam account (including feedback) and User ID and/or password to another party without the express, written consent of Roam;

Distribute viruses or any other technologies that may harm Roam, the Roam website, or the interests, information or property of Roam Users;

Copy, modify, or distribute content from the Roam website, or misuse or otherwise infringe upon Roam’s copyrights and/or trademarks; or

Harvest or otherwise collect information about Users, including email addresses and financial information, without each User’s express, written consent.

By entering into this Agreement, each Party represents and warrants to the other Party that:

It has the legal right to enter into this Agreement and to perform its obligations hereunder;

It has taken all necessary action to authorize the execution and delivery of this Agreement and the performance of its obligations hereunder, including, but not limited to, delivering an executed copy of each and any form required by Roam;

This Agreement constitutes a legal, valid and binding agreement of such Parties;

It has all necessary power and authority to perform its obligations in this Agreement; and

It has obtained all necessary consents, authorizations and approvals from any third party (including any federal, state or local governmental or regulatory authority) which may be required for such Party to execute and deliver this Agreement and consummate the transactions contemplated hereby, including, but not limited to, the release of any contractual obligations owed to any third party.

**II. Service Availability; Cancellation by Roam.**

Roam may change, suspend or terminate any Service, or change or modify its Fees at any time and at its sole discretion unless otherwise agreed to by the Parties. To the extent permitted by law, these changes are effective pursuant to the terms of Article 1 and Article 2, Section III hereof.

User understands and agrees that Roam has no obligation to store, maintain or otherwise provide User with a copy of any content or information that you or others provide, except to the extent required by applicable law and as noted in our Privacy Policy.

Without limiting other remedies, Roam may limit, suspend, or terminate Roam’s Services and User accounts, prohibit access to Roam’s website, delay or remove hosted content, and take technical and legal steps to prevent User from accessing the Roam website if Roam believes in good faith that User is creating problems or possible legal liabilities, is engaging in fraudulent activity, or is acting inconsistently with the letter or spirit of the Roam Terms and Conditions.

**III. Fees.**

Roam’s hosting services are subject to “**Fees**”, based upon the Roam Fee Schedule or based upon a separate fee schedule that is entered into directly by and between Roam and User in a separate agreement. Roam reserves the right to change its Fees from time to time. Changes to the Roam Fee Schedule are effective after Roam provides User with at least fourteen (14) days’ notice by posting the changes on the Roam website.

Roam may choose to temporarily change the Fees for Roam’s Services for promotional events or for new services, and such changes are effective when Roam posts the temporary promotional event or new service on the Roam website, subject to the conditions of such promotional events or new services.

**IV. Limitation of Liability.**

Neither Party will hold the other responsible for third party Users’ actions or inactions, including comments written or posted on the Roam site.

Neither Party will be liable for any loss of money, goodwill, or reputation, or any special, indirect, or consequential damages arising out of the use of Roam.

Notwithstanding the foregoing, and in recognition of the relative risks and benefits of this arrangement between User and Roam, the risks have been allocated such that the User agrees, to the fullest extent permitted by law, to limit the liability of Roam to any third party for any and all claims, losses, costs, damages of any nature whatsoever or claims expenses from any cause or causes, including attorneys’ fees and costs and expert witnesses’ fees and costs, so that the total aggregate liability owed by Roam to User or to any third party shall not exceed the greater of (a) the total Fees User paid to Roam in the twelve (12) months prior to the action giving rise to the liability, and (b) U.S. $100.00.

**V. Release.**

If either Party has a dispute with one or more Users, this Party releases the other Party (and their officers, directors, agents, subsidiaries, joint ventures and employees) from claims, demands and damages (actual and consequential) of every kind and nature, known and unknown, arising out of or in any way connected with such disputes.

**VI. Access and Interference.**

The information on the Roam website is proprietary or is licensed to Roam by Roam’s Users or third parties. User agrees that it will not use any robot, spider, scraper or other automated means to access the Roam website for any purpose without Roam’s express, written permission and consent.

Additionally, User agrees that User will not:

Take any action that imposes or may impose (as interpreted by Roam at its sole discretion) an unreasonable or disproportionately large load on Roam’s infrastructure;

Copy, reproduce, modify, create derivative works from, distribute, or publicly display any content (except for User’s information) from the Roam website without the express, written permission and consent of Roam and the appropriate third party, as applicable;

Interfere or attempt to interfere with the proper working of the Roam website or any activities conducted on the Roam website; or

Bypass Roam’s robot exclusion headers or any other such measures that Roam may use to prevent or restrict access to the Roam website.

**VII. Privacy.**

Roam views protection of User’s privacy as a very important software principle. Roam will use User’s information only as described in the Roam Privacy Policy. Roam stores and processes User’s information on computers that may be located anywhere in the world, including but not limited to, the United States or other countries, that are protected by physical as well as technological security devices. User can access and modify the information User provides us and may choose not to receive certain communications by opting out of emails received via an “Unsubscribe” or similar opt-out mechanism. Roam reserves the right to use third parties to verify and certify Roam’s privacy principles. For a complete description of how Roam uses and protects User’s personal information, please see the Roam [[Privacy Policy]], available on www.roamresearch.com.

**VIII. Indemnity.**

If any claim or demand, including reasonable attorneys’ fees, is made by any third party due to or arising out of a breach of this Agreement or violation of any law or the rights of a third party by a Party to this Agreement (the “**Offending Party**”), the Offending Party will indemnify and hold harmless the other Party (and their officers, directors, agents, subsidiaries, joint ventures and employees) from such claim or demand.

**IX. No Agency; Advice.**

No agency, partnership, joint venture, employee-employer or franchiser-franchisee relationship is intended or created by this Agreement.

User understands that Roam is not qualified to give either legal advice or tax advice regarding prospective transactions or otherwise, and User shall not rely on Roam for advice on such matters.

**X. Notices.**

Except where explicitly stated otherwise, such as in Article 1 and in Article 2, Section III hereof, notice shall be served on Roam's Delaware registered agent (in the case of Roam) or on the agent or representative that User provides to Roam during the registration process (or to the Manager, agent, representative on file in User’s Roam account at the time of notice, if different) (in the case of User), where the law requires such service. Alternatively, Roam may give User legal notice by certified mail to the address provided during the registration process, where the law permits such service. In such case, notice shall be deemed to be complete on the day the certified mail receipt is signed by User or User’s Manager, agent or representative.

**XI. Governing Law.**

This Agreement shall be governed by and interpreted in accordance with the laws of the State of California and of the United States without giving effect to the doctrine of conflict of laws. All claims arising out of this Agreement that are not governed by Section XII hereof shall be resolved in accordance with the laws of the State of California in a court of competent jurisdiction.

**XII. Disclaimer.**

YOUR USE OF THE SERVICE IS AT YOUR SOLE RISK. THE SERVICE IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. THE SERVICE IS PROVIDED WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT OR COURSE OF PERFORMANCE.

ROAM ITS SUBSIDIARIES, ITS AFFILIATES, AND ITS LICENSORS DO NOT WARRANT THAT (A) THE SERVICE WILL FUNCTION UNINTERRUPTED, SECURE OR AVAILABLE AT ANY PARTICULAR TIME OR LOCATION; (B) ANY ERRORS OR DEFECTS WILL BE CORRECTED; (C) THE SERVICE IS FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS; OR (D) THE RESULTS OF USING THE SERVICE WILL MEET YOUR REQUIREMENTS.

**XIII. Resolution of Disputes.**

ANY DISPUTE, CLAIM OR CONTROVERSY ARISING OUT OF OR RELATING TO THIS AGREEMENT, OR THE BREACH, TERMINATION, ENFORCEMENT, INTERPRETATION OR VALIDITY THEREOF, INCLUDING THE DETERMINATION OF THE SCOPE OR APPLICABILITY OF THIS AGREEMENT TO ARBITRATE, WHICH CANNOT BE RESOLVED BY NEGOTIATION OR MEDIATION BETWEEN THE PARTIES, SHALL BE SETTLED BY FINAL AND BINDING ARBITRATION WITH ONE ARBITRATOR IN A VENUE MOST CONVENIENT TO THE PARTIES. THE ARBITRATION SHALL BE ADMINISTERED BY JAMS PURSUANT TO ITS COMPREHENSIVE ARBITRATION RULES AND PROCEDURES AND IN ACCORDANCE WITH THE EXPEDITED PROCEDURES IN THOSE RULES.

THE COSTS OF THE ARBITRATION SHALL BE SHARED EQUALLY BETWEEN THE PARTIES, EXCEPT THAT EACH PARTY SHALL BE RESPONSIBLE FOR ITS OWN ATTORNEYS’ FEES AND COSTS IN PREPARING AND PRESENTING ITS CASE. THE ARBITRATOR’S AWARD MAY BE CONFIRMED, ENTERED, AND ENFORCED AS A FINAL JUDGMENT IN ANY COURT OF COMPETENT JURISDICTION. THIS CLAUSE SHALL NOT PRECLUDE THE PARTIES FROM SEEKING PROVISIONAL REMEDIES TO MAINTAIN THE STATUS QUO AND IN AID OF ARBITRATION FROM A COURT OF COMPETENT JURISDICTION; PROVIDED, HOWEVER, THAT, SHOULD USER FILE A CLAIM CONTRARY TO THIS SECTION, ROAM MAY RECOVER ATTORNEYS’ FEES AND COSTS INCURRED TO ADDRESS SUCH IMPROPER CLAIM, PROVIDED THAT ROAM HAS NOTIFIED USER IN WRITING OF THE IMPROPERLY FILED CLAIM(S), AND USER HAS FAILED TO PROMPTLY WITHDRAW THE CLAIM(S).

THE ARBITRATOR’S AWARD SHALL BE ISSUED IN WRITING AND CONFINED TO A STATEMENT OF THE AMOUNT OF DAMAGES (IF ANY) AWARDED TO EITHER OR BOTH PARTIES ON THE CLAIMS AND COUNTERCLAIMS SUBMITTED TO THE ARBITRATOR. THE ARBITRATOR SHALL BE AUTHORIZED TO AWARD COMPENSATORY DAMAGES, BUT SHALL NOT BE AUTHORIZED (I) TO AWARD NON-ECONOMIC DAMAGES, SUCH AS FOR EMOTIONAL DISTRESS, PAIN AND SUFFERING OR LOSS OF CONSORTIUM, (II) TO AWARD PUNITIVE DAMAGES, OR (III) TO REFORM, MODIFY OR MATERIALLY CHANGE THIS AGREEMENT OR ANY OTHER AGREEMENTS CONTEMPLATED HEREUNDER; PROVIDED, HOWEVER, THAT THE DAMAGE LIMITATIONS DESCRIBED IN PARTS (I) AND (II) OF THIS TERM WILL NOT APPLY IF SUCH DAMAGES ARE STATUTORILY IMPOSED. THE ARBITRATOR SHALL ALSO BE AUTHORIZED TO GRANT ANY TEMPORARY, PRELIMINARY OR PERMANENT EQUITABLE REMEDY OR RELIEF HE OR SHE DEEMS JUST AND EQUITABLE AND WITHIN THE SCOPE OF THIS AGREEMENT, INCLUDING, WITHOUT LIMITATION, AN INJUNCTION OR ORDER FOR SPECIFIC PERFORMANCE.

BY AGREEING TO THIS BINDING ARBITRATION PROVISION, THE PARTIES UNDERSTAND THAT THEY ARE WAIVING CERTAIN RIGHTS AND PROTECTIONS THAT MAY OTHERWISE BE AVAILABLE IF A CLAIM BETWEEN THE PARTIES WERE RESOLVED BY LITIGATION IN A COURT OF LAW.

**XIV. Termination or Cancellation of Agreement.**

We may terminate or suspend your account and bar access to the Service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms of Service.

If you wish to terminate your account, you may do so by contacting us at support@roamresearch.com. After 60 days, the Content will be deleted from our servers and can no longer be recovered.

If your account is terminated by us, you will (on request) be sent a copy of all of your work in Roam in plain text and machine readable form. (This is not guaranteed if termination is at your request.)

**XV. Entire Agreement; Amendment.**

**Entire Agreement.** Together with the Roam Terms of Service and the Roam Privacy Policy, this Agreement constitutes the entire agreement between the Parties, and there are no other representations, oral or otherwise, regarding the subject of this Agreement that are binding on either Party.

**Amendment.** Together with the Roam Terms of Service and the Roam Privacy Policy, Roam may amend this Agreement from time to time. Roam shall provide notice by email, to the email address on file in User’s Roam account at the time of notice, if changes are made to the Roam User Agreement, the Roam Terms of Service, or the Privacy Policy. After such notice has been provided, continued use of the Services constitutes understanding and acceptance of these Terms and Conditions.

**XVI. Severability.**

Together with the Roam Terms of Service and the Roam Privacy Policy, the terms of this Agreement are severable such that if any term or provision is declared by a court of competent jurisdiction to be illegal, void, or otherwise unenforceable, the remainder of the provisions herein shall continue to be valid and enforceable.

**XVII. Survival.**

The following Sections survive termination, cancellation, or expiration of this Agreement: Section III. Fees (with respect to Fees owed for Services); Section IV. Limitation of Liability; Section V. Release; Section VI. Access and Interference; Section VII. Privacy; Section VIII. Indemnity; Section IX. No Agency; Advice; Section X. Notices; Section XI. Governing Law; Section XII. Resolution of Disputes; and Section XV. Severability. 

**XVIII. Non-waiver.**

The failure or delay of either Party to exercise any of its rights hereunder for breach thereof shall not be deemed to be a waiver of such rights, and no waiver by either Party, whether written or oral, express or implied, of any rights or arising from this Agreement subsequent occasion; and no concession by either Party shall be treated as an implied modification of the Agreement, unless specifically agreed to in a writing signed by the Parties.

### Article 3. Terms of Service

Roam provides a platform wherein Users can create and manage an online database for organizing and evaluating knowledge.  These Terms of Service apply to all Users of the Roam platform.

**I. Content.**

Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material ("Content") on the Service. You are responsible for the Content that you post on or through the Service, including its legality, reliability, and appropriateness.

By posting Content on or through the Service, you represent and warrant that: (a) the Content is yours and/or you have the right to use it and the right to grant us the rights and license as provided in these Terms, and (b) that the posting of your Content on or through the Service does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person or entity. We reserve the right to terminate the account of anyone found to be infringing on a copyright. 

You retain any and all of your rights to any Content you submit, post or display on or through the Service and you are responsible for protecting those rights. We take no responsibility and assume no liability for Content you or any third-party posts on or through the Service. When you post Content into certain Databases, you will be able to designate whether such Content is made publicly or privately available.

As a condition of your use of the Service, you grant Roam a nonexclusive, perpetual, irrevocable, royalty-free, worldwide, transferable, sub-licenseable license to access, use, host, cache, store, reproduce, transmit, display, publish, distribute, modify and adapt and create derivative works (either alone or as part of a collective work) from your public Content. This license does not apply to content in private databases. **Furthermore, while Roam has the technical ability to access private content, we agree to never access private content without written or verbal consent from you - excluding cases where we are compelled by legal authorities.** As part of the foregoing license grant you agree that (a) the other users of the Service shall have the right to comment on and/or tag your public Content that you make available to them and/or to use, publish, display, modify or include a copy of your public Content that you make available to them, and (b) we have the right to make any of your public Content available to third parties, so that those third parties can distribute, make derivative works of, comment on and/or analyze your Content on other media and services (either alone or as part of a collective work); except that the foregoing (a) and (b) shall not apply to any of your Content that you post privately for non-public display on the Service.

By posting Content that is set for public access to the Service, you grant us the right to display such public Content on and through the Service. Roam has the right but not the obligation to monitor all Content provided by users. In addition, any Content found on or through this Service that is not originally submitted, posted, or displayed by Users of the Service is the property of Roam or used with permission. You may not distribute, modify, transmit, reuse, download, repost, copy, or use said Content, whether in whole or in part, for commercial purposes or for personal gain, without express advance written permission from us.

You agree that Roam has the right, but not the obligation, to remove any Content from the Service if Roam determines in its sole discretion that such Content has violated these Terms, the Roam Privacy Policy, applicable law, or the privacy rights, publicity rights, intellectual property, contract rights or any other rights of any person or entity, or if Roam determines in its sole discretion that such Content poses a risk of harm to Roam, other users of the Service or third parties.

Any content stored on the Service will be stored indefinitely, unless it is explicitly deleted. This process is described in Article 2, Section XIV, Termination or Cancellation of Agreement.

**II. Copyright Policy.**

We respect the intellectual property rights of others. It is our policy to respond to any claim that Content posted on the Service infringes on the copyright or other intellectual property rights ("Infringement") of any person or entity. It is our policy, in appropriate circumstances and at our discretion, to disable or terminate the accounts of users who repeatedly Infringe copyrights or intellectual property rights of others.

If you are a copyright owner, or authorized on behalf of one, and you believe that any content, materials or works uploaded, downloaded or appearing on the Service have been copied in a way that constitutes copyright infringement, you may submit a notification pursuant to the Digital Millennium Copyright Act (DMCA) by providing our copyright agent with the following information in writing (see 17 U.S.C 512(c)(3) for further detail):

an electronic or physical signature of the person authorized to act on behalf of the owner of the copyright's interest;

a description of the copyrighted work that you claim has been infringed;

identification of the allegedly infringing material on the Service, including URL or other specific location on the Service where the material that you claim is infringing is located;

your address, telephone number, and email address;

a statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law;

a statement by you, made under penalty of perjury, that the above information in your notice is accurate and that you are the copyright owner or authorized to act on the copyright owner's behalf.

**III. Intellectual Property.**

The Service and its original content (excluding Content provided by users), features and functionality are and will remain the exclusive property of Roam and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Roam.

**IV. Databases.**

Content submitted, posted or modified by users in the Service is organized into separated sections we refer to as “Databases.”

There are two general types of Databases on the Service:

“Private Databases” that can only be accessed by the user that created the Database, unless you choose to grant full editor access to another specific user(s). You may also choose to grant page-level permissions to another user(s) for collaboration, but they will not have access to the rest of your content. Databases are private by default.

“Public Databases” that can be accessed by anyone with the link. The user that created the Database retains administrative rights. You can allow the database to be fully editable by the public, or you can restrict access to be read-only.

In the Service, you can work across multiple Databases at once, meaning your single account can access your own Private Database(s) and different Public Database(s). Databases are completely separate, and you won’t be able to link any Content between them (although you can transfer copies of Content from one Database to another). You can also export your User Content from your Databases for use outside of the Service via the application.

**V. Accounts.**

You are responsible for maintaining the confidentiality of your account and password, including but not limited to the restriction of access to your computer and/or account. You agree to accept responsibility for any and all activities or actions that occur under your account and/or password, whether your password is with our Service or a third-party service. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.

You may not use as a username the name of another person or entity that is not lawfully available for use, or a name or trademark that is subject to any rights of another person or entity other than you, without appropriate authorization. You may not use as a username any name that is offensive, vulgar or obscene.

You may not use the Service if you are 13 years of age or younger. By using the Service, you represent and warrant that you are over the age of 13.

**VI. Subscriptions & Fee Schedule.** 

Payment obligations are non-cancellable, and fees paid are non-refundable and there are no credits for partially used Subscription periods. Certain refund requests for Subscriptions may be considered by Roam on a case-by-case basis and granted in sole discretion of Roam. 

Subscription Types (June 2020) 

Free Trial 

You'll be able to try Roam for free for 14 days. This trial includes the creation of one private or public database.  

If you cancel your Free Trial, you will still be able to read and export your notes indefinitely. If you do not cancel your Free Trial, it will be converted into a Standard Subscription by default at the end of that period. 

Standard Subscription

A standard subscription includes the creation of up to three public or private databases. Rates may differ for monthly and annual payment plans. 

As of June 2020, standard subscription fees are: 

$15 per month when billed monthly 

$165 per year when billed annually 

Long Haul Subscription 

A long haul subscription includes the creation of up to three public or private databases, as well as a dedicated offline-only mode. 

As of June 2020, long haul subscription fees are: 

$500 / 5 years 

Discounted subscriptions or promotional rates may also be offered and granted at any time, and are subject to change in sole discretion of Roam. 

**VII. Communications From Roam.**

By creating an account on our Service, you agree to subscribe to newsletters or marketing materials and other promotional information we may send. However, you may opt out of receiving any, or all, of these marketing communications from us by following the unsubscribe link or instructions provided in any email we send. Please note that we may still send you transactional or administrative messages related to the Service even after you have opted out of receiving marketing communications.

**VIII. Feedback.**

We welcome feedback, comments and suggestions for improvements to the Service (“Feedback”). You acknowledge and expressly agree that any contribution of Feedback does not and will not give or grant you any right, title or interest in the Service or in any such Feedback. All Feedback becomes the sole and exclusive property of Roam, and Roam may use and disclose Feedback in any manner and for any purpose whatsoever without further notice or compensation to you and without retention by you of any proprietary or other right or claim. You hereby assign to Roam any and all right, title and interest (including, but not limited to, any patent, copyright, trade secret, trademark, show-how, know-how, moral rights and any and all other intellectual property right) that you may have in and to any and all Feedback.

