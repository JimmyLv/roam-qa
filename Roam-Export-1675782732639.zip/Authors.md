[[Paul Graham]]

