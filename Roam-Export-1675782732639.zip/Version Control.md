Version control helps you create different versions of of the same block, often used when you want to make multiple drafts of something

This is an example with Roam's elevator pitch, click on the numbers to see the different versions

Roam is a tool to compound knowledge, something I'd be proud to look back on how my brain has grew and evolved 20 years later.

Key Commands::

`Ctrl+,` for Windows

`Cmd+,` for Mac

