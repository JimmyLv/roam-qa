## Community Videos::

### Roam: The Best Personal CRM Ever by [[Nat Eliason]]

{{[[video]]: https://www.youtube.com/watch?v=cRDgrdlfYdE&ab_channel=NatEliason}}
#[[Page References]] | #[[Sidebar]] | #[[Linked References]] | #[[Attributes]]

### Mini CRM in Roam Research: Logging Meeting Notes by [[R.J. Nestor]]

{{[[video]]: https://www.youtube.com/watch?v=CnakhkONQ_g&ab_channel=R.J.Nestor}}
#[[Page References]] | #[[Sidebar]] | #[[Daily Notes]] | #[[Tags]] | #[[Indentation]] | #[[Linked References]] | #[[Filter]] | #[[Attributes]] 

## Articles::

### [Using Roam Research as a Customer Relationship Manager](https://thesweetsetup.com/using-roam-research-as-a-customer-relationship-manager/) by [[Josh Ginter]]

#[[Page References]] | #[[Attributes]] | #[[Templates]] | #[[Daily Notes]] #[[Current time]] | #[[Task Management]] | #[[Calculator]] | #[[Pomodoro timer]] | #[[Kanban]] 

### [Use Roam Research as a Personal CRM - Nicolo S's pro tip about Roam Research | YourStack](https://yourstack.com/pro-tips/340-use-roam-research-as-a-personal-crm) by [[Nicolo S]]

#[[Attributes]] | #[[Page References]]

### [Roam Research: Why I Love It and How I Use It](https://www.nateliason.com/blog/roam#crm) by [[Nat Eliason]]

#[[Attributes]] | #[[Page References]] | #[[Linked References]]



