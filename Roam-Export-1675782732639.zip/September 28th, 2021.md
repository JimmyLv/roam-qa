[[September 28th, 2021]]

### [[Quality of Life Improvements]] ✨

All settings, including keyboard shortcut customizations accessible from [[Command Palette]] 

`cmd-p` on [[Mac]]

`control-p` on [[Windows]] or [[Linux]]

__handy way to discover or remember different keyboard shortcuts__

Example::

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fhelp%2FBykG_v_8KV.png?alt=media&token=76c76dce-6346-4b6e-9435-843f07219956)

